/*
 * SimpleModal Contact Form
 * http://www.ericmmartin.com/projects/simplemodal/
 * http://code.google.com/p/simplemodal/
 *
 * Copyright (c) 2010 Eric Martin - http://ericmmartin.com
 *
 * Licensed under the MIT license:
 *   http://www.opensource.org/licenses/mit-license.php
 *
 * Revision: $Id: contact.js 243 2010-03-15 14:23:14Z emartin24 $
 *
 */
var eee2=0;
var status_conf='';
var wd=470;
var href='';
var get_pdf='';

jQuery(function ($) {
	var contact = {
		message: null,
		
		init: function () {
			
			$('#contact-form input.contact, #contact-form a.contact, .pnv a.contact').click(function (e) {
				

				var id=this.id.replace(/[a-z_]*/,"");

				eee2=0;
				
				if ($(this).is("#seminar")) { status_conf='&conf=on'; eee2=3; wd=800;}
				if ($(this).is("#get_pdf")) { status_conf='&get_pdf=on'; wd=470 ; 

					/*var get_pdf=$.cookie('get_pdf');
					href=$(this).attr('val');
					


					if (get_pdf)
					{
						window.open('/ajax/pdf/'+href+'.pdf');
						status_conf='&get_pdf=off';
					}*/



				}
				if ($(this).is("#os_smk")) { status_conf='&os_smk=on'; /*alert(1)*/}
				if ($(this).is("#anketa")) { status_conf='&anketa=on'; eee2=3; wd=800; }
			

				if (status_conf!='&get_pdf=off')			
				{
					
					e.preventDefault();
					
					

					
					var p_url=location.search.substring(1);
					var parametr=p_url.split("&");		
					var values= new Array();
					for(i in parametr) 
					{
						var j=parametr[i].split("=");
						values[j[0]]=unescape(j[1]);
					}
					if (!values["id"]) if (id!='') {  values["id"]=id; }
					//alert(values["id"]);
					// load the contact form using ajax

					values["id"] = eee2==3 ? values["id"]: 'undefined';

					$.get("/js/contact.php?id="+values["id"]+status_conf, function(data){
						
						// create a modal dialog with the data
						$(data).modal({
							closeHTML: "<a href='#' title='Close' class='modal-close'>x</a>",
							position: ["15%",],
							overlayId: 'contact-overlay',
							containerId: 'contact-container',
							containerCss :{width:wd},
							onOpen: contact.open,
							onShow: contact.show,
							onClose: contact.close
						});
					});
				}
			});
			
			
			$('#contact-form2 input.contact2, #contact-form2 a.contact2').click(function (e) {
				e.preventDefault();
				
				var tt="";
				var kol=0;
				//document.eee.checkgroup[0].value="123";
				for (i=0; i<document.eee.checkgroup.length; i++)
				{
					if (document.eee.checkgroup[i].checked==true) {tt=tt+document.eee.checkgroup[i].value+"_"; kol++}
				}
				//tt="99999_34_";

				var p_url=location.search.substring(1);
				var parametr=p_url.split("&");		
				var values= new Array();
				
				for(i in parametr) 
				{
					var j=parametr[i].split("=");
					values[j[0]]=unescape(j[1]);
				}	

				// load the contact form using ajax
				if (kol) 
				{	
					eee2=1;
			
					$.get("/js/contact.php?id="+values["id"]+"&act="+document.eee.act.value+"&tt="+tt, function(data){
					// create a modal dialog with the data
						$(data).modal({
							closeHTML: "<a href='#' title='Close' class='modal-close'>x</a>",
							position: ["15%",],
							
							overlayId: 'contact-overlay',
							containerId: 'contact-container',
							onOpen: contact.open,
							onShow: contact.show,
							onClose: contact.close
						});
					});
				}
				else 
				{
					eee2=2;
					
					$.get("/js/contact.php?id="+values["id"]+"&err=1", function(data){
					// create a modal dialog with the data
					
						$(data).modal({
							closeHTML: "<a href='#' title='Close' class='modal-close'>x</a>",
							position: ["15%",],
							overlayId: 'contact-overlay',
							containerId: 'contact-container',
							onOpen: contact.open,
							onShow: contact.show,
							onClose: contact.close
						});
					});
				}

			});			
		},
		open: function (dialog) {
			// add padding to the buttons in firefox/mozilla
			if ($.browser.mozilla) {
				$('#contact-container .contact-button').css({
					'padding-bottom': '2px'
				});
			}
			// input field font size
			if ($.browser.safari) {
				$('#contact-container .contact-input').css({
					'font-size': '.9em'
				});
			}
		if (wd==800) {	$('#contact-container .contact-top').css({'background':'url(/contact/img/contact/form_top_sh.gif) no-repeat'});
						$('#contact-container .contact-bottom').css({'background':'url(/contact/img/contact/form_bottom_sh.gif) no-repeat'});
						$('#contact-container .contact-message').css({'position':'absolute','top':'5px','width':'800px'});
						$('#contact-container .contact-loading').css({'margin':'24px 0 0 373px'});
						$('#contact-container').css({'margin-top':'-90px'});
					}
			switch (eee2)
			{
				case 0: h=360;
				break;
				case 1: h=410;
				break;
				case 2: h=180;
				break;
				case 3: h=560; 
				break;				
			}
			// dynamically determine height
			
			if ($('#contact-subject').length) {
				h += 26;
			}
			if ($('#contact-cc').length) {
				h += 22;
			}

			var title = $('#contact-container .contact-title').html();
			$('#contact-container .contact-title').html('��������...');
			dialog.overlay.fadeIn(200, function () {
				dialog.container.fadeIn(200, function () {
					dialog.data.fadeIn(200, function () {
						$('#contact-container .contact-content').animate({
							height: h
						}, function () {
							$('#contact-container .contact-title').html(title);
							$('#contact-container form').fadeIn(200, function () {
								$('#contact-container #contact-name').focus();
								$('#contact-container #contact-tel');
							
								/*$('#contact-container .contact-cc').click(function () {
									var cc = $('#contact-container #contact-cc');
									cc.is(':checked') ? cc.attr('checked', '') : cc.attr('checked', 'checked');
								});*/

								// fix png's for IE 6
								if ($.browser.msie && $.browser.version < 7) {
									$('#contact-container .contact-button').each(function () {
										if ($(this).css('backgroundImage').match(/^url[("']+(.*\.png)[)"']+$/i)) {
											var src = RegExp.$1;
											$(this).css({
												backgroundImage: 'none',
												filter: 'progid:DXImageTransform.Microsoft.AlphaImageLoader(src="' +  src + '", sizingMethod="crop")'
											});
										}
									});
								}
							});
						});
					});
				});
			});
		},
		show: function (dialog) {
			$('#contact-container .contact-send').click(function (e) {
				var id=this.id.replace(/[a-z_]*/,"");
				e.preventDefault();
				// validate form
				if (contact.validate()) {
					var msg = $('#contact-container .contact-message');
					
					msg.fadeOut(function () {
						msg.removeClass('contact-error').empty();
					});
					
					$('#contact-container .contact-title').html('��������...<p><br></p>');
					$('#contact-container form').fadeOut(200);
					$('#contact-container .contact-content').animate({ height: '190px' }, function () {
						$('#contact-container .contact-loading').fadeIn(200, function () {
							
							var p_url=location.search.substring(1);
							var parametr=p_url.split("&");		
							var values= new Array();
							for(i in parametr) {
							    var j=parametr[i].split("=");
							    values[j[0]]=unescape(j[1]);
							}						//alert(status_conf);
							
							if (!values["id"] && id!='') {  values["id"]=id; }
							//alert(id);
							$.ajax({
								url: '/js/contact.php',
								data: $('#contact-container form').serialize() + '&id='+values['id']+'&action=send'+status_conf,
								type: 'post',
								cache: false,
								dataType: 'html',
								success: function (data) {
								//alert(status_conf);
									$('#contact-container .contact-loading').fadeOut(200, function () {
										$('#contact-container .contact-title').html('�������!');
										
										msg.html(data).fadeIn(200);

										/*if (status_conf=='&get_pdf=on')
										{


											window.open('/ajax/pdf/'+href+'.pdf');

										}*/
										
									});
								},
								error: contact.error
							});
						});
					});
				}
				else {
					if ($('#contact-container .contact-message:visible').length > 0) {
						var msg = $('#contact-container .contact-message div');
						msg.fadeOut(200, function () {
							msg.empty();
							contact.showError();
							msg.fadeIn(200);
						});
					}
					else {
						$('#contact-container .contact-message').animate({
							height: '50px'
						}, contact.showError);
					}
					
				}
			});
		},
		close: function (dialog) {
			$('#contact-container .contact-message').fadeOut();
			$('#contact-container .contact-title').html('����� �������...');
			$('#contact-container form').fadeOut(200);
			$('#contact-container .contact-content').animate({
				height: 40
			}, function () {
				dialog.data.fadeOut(200, function () {
					dialog.container.fadeOut(200, function () {
						dialog.overlay.fadeOut(200, function () {
							$.modal.close();
						});
					});
				});
			});
		},
		error: function (xhr) {
			alert(xhr.statusText);
		},
		validate: function () {
			contact.message = '';

			
			if (eee2==1)			
			{   contact.message+=contact.chek_name();
				contact.message+=contact.chek_index();
				contact.message+=contact.chek_adr();
					
			}
			if (!status_conf) {
			contact.message+=contact.chek_name();
			contact.message+=contact.chek_tel();
			contact.message+=contact.chek_comp();
			contact.message+=contact.chek_emale(2);
			contact.message+=contact.chek_message();
			} else {
				switch (status_conf)
				{
					case '&get_pdf=on':
					contact.message+=contact.chek_name();
					contact.message+=contact.chek_comp();
					contact.message+=contact.contactrec();

					break;
					case '&conf=on':
					contact.message+=contact.chek_name();
					contact.message+=contact.chek_comp();
					contact.message+=contact.chek_adr();
					contact.message+=contact.chek_tel();
					contact.message+=contact.chek_emale(2);

					break;					
					case '&os_smk=on':	
									contact.message+=contact.chek_name();
									contact.message+=contact.chek_message();
									contact.message+=contact.chek_emale(1);
					break;
					case '&anketa=on': 
									contact.message+=contact.chek_name();
									if (($('input[name=quest1]').is(":checked")==false) || ($('input[name=quest1]:checked').val()==3) && !$('input[name=quest1-text]').val()) contact.message += '�������� �� ������ �1. ';
									if ($('input[name=quest2]').is(":checked")==false) contact.message += '��������� ���������� ������. ';
									if (($('input.quest3c').is(":checked")==false) || ($('input.quest3c:checked').val()==10) && !$('input[name=quest3-text]').val()) contact.message += '�������� �� ������ �3. ';
									if (($('input.quest4c').is(":checked")==false) || ($('input.quest4c:checked').val()==5) && !$('input[name=quest4-text]').val()) contact.message += '�������� �� ������ �4. ';
									
					break;
				}
			}

			if (contact.message.length > 0) {
				return false;
			}
			else {
				return true;
			}
			
		},
		validateindex:function (index) {
		if (index.length != 6) return false;
		if (!/^[-0-9\.]*$/.test(index)) return false;
		if (index.indexOf("0")==0)return false;
		return true;
		},
		contactrec:function() // �������� ������� ���������
		{
			var message='';

			if ($('#contact-container #contact-email').val())
			{
				message+=contact.chek_emale(2);
			} else {
				if ($('#contact-container #contact-tel').val()) {
					message+=contact.chek_tel();
				} else {
					message='������� ���������� ������. ';
				}
			}

			return message;
		},
		chek_name:function() { //�������� �����
			var message='';
			if (!$('#contact-container #contact-name').val()) {
					message = '������� ���. ';
			}
			return message;
		},
		chek_family:function() { //�������� �������
			var message='';
			if (!$('#contact-container #contact-family').val()) {
					message = '������� �������. ';
			}				
			return message;
		},
		chek_dolj:function() { //�������� ���������
			var message='';
			if (!$('#contact-container #contact-dolj').val()) {
					message = '������� ���������. ';
			}			
			return message;
		},
		
		chek_message:function() { //�������� ���������
			var message='';
			if (!$('#contact-container #contact-message').val()) {
					message = '������� ���������.';
			}			
			return message;
		},
		chek_emale: function(No) { //�������� ����
			var message='';
			var email = $('#contact-container #contact-email').val();
			if (No==1) {
				if (email) {
					if (!validateEmail(email)) {
							message = '������������ E-mail.';
					}
				}
			} else {
				if (!email) {
					message = '������� E-mail. ';
				}
				else {
					if (!validateEmail(email)) {
						message = 'E-mail �������. ';
					}			
				}
			}
			return message;		
		},
		chek_tel:function() { //�������� ��������
			var message='';
			if (!$('#contact-container #contact-tel').val()) {
				message = '������� �������. ';
			}			
			return message;
		},		
		chek_comp:function() { //�������� ��������
			var message='';
			if (!$('#contact-container #contact-comp').val()) {
				message = '������� �������� ��������. ';
			}			
			return message;
		},			
		chek_index:function() { //�������� �������
			var message='';
			var index = $('#contact-container #contact-index').val();
			if (!index) {
					message = '������� ������. ';
			}
			else {
					if (!contact.validateindex(index)) {
							message = '������������ ������. ';
					}
			}		
			return message;
		},	
		chek_adr:function() { //�������� ������
			var message='';
			if (!$('#contact-container #contact-adr').val()) {
					message += '������� �����. ';
			}			
			return message;
		},			
	
		showError: function () {
			$('#contact-container .contact-message')
				.html($('<div class="contact-error"></div>').append(contact.message))
				.fadeIn(200);
		}
	};

	contact.init();

});
function validateEmail (email) {
		
			var at = email.lastIndexOf("@");

			// Make sure the at (@) sybmol exists and  
			// it is not the first or last character
			if (at < 1 || (at + 1) === email.length)
				return false;

			// Make sure there aren't multiple periods together
			if (/(\.{2,})/.test(email))
				return false;

			// Break up the local and domain portions
			var local = email.substring(0, at);
			var domain = email.substring(at + 1);

			// Check lengths
			if (local.length < 1 || local.length > 64 || domain.length < 4 || domain.length > 255)
				return false;

			// Make sure local and domain don't start with or end with a period
			if (/(^\.|\.$)/.test(local) || /(^\.|\.$)/.test(domain))
				return false;

			// Check for quoted-string addresses
			// Since almost anything is allowed in a quoted-string address,
			// we're just going to let them go through
			if (!/^"(.+)"$/.test(local)) {
				// It's a dot-string address...check for valid characters
				if (!/^[-a-zA-Z0-9!#$%*\/?|^{}`~&'+=_\.]*$/.test(local))
					return false;
			}

			// Make sure domain contains only valid characters and at least one period
			if (!/^[-a-zA-Z0-9\.]*$/.test(domain) || domain.indexOf(".") === -1)
				return false;	

			return true;
		}
/*function chek_name(message)
{
	if (!$('#contact-container #contact-name').val()) {
			message += '������� ���. ';
	}
	return message;
}*/
/*function chek_emale(message)
{
	if (!$('#contact-container #contact-name').val()) {
			message += '������� ���. ';
	}
	return message;
}
*/