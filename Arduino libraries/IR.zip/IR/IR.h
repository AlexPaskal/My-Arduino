#ifndef IR_h
#define IR_h

#if defined(ARDUINO) && ARDUINO >= 100
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif 
#include <EEPROM.h>

class IR

{
        public:
                //IR();
                void pinIR(byte x);
		void cycles(byte x);
		void readEEPROM();
		int readIR();
		void test();
                boolean writeMEMORY();
		boolean writeEEPROM();
		
};

#endif // #ifndef IR_h